'use strict';

exports.say = item => {
  console.log(`调用了工具类 ${item}`);
};
